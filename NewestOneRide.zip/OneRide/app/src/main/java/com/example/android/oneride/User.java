package com.example.android.oneride;

public class User {
    public String id;
    public String email;
    public String password;
    public String place;
    public String phone;

    public User(String id, String email, String password, String place, String phone) {
        this.id = id;
        this.email = email;
        this.password = password;
        this.place = place;
        this.phone = phone;
    }

}