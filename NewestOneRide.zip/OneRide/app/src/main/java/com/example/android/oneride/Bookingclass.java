package com.example.android.oneride;

public class Bookingclass {
    public String Bid;
    public String type;
    public String brand;
    public String pick;
    public String drop;
    public String date;
    public String name;


    public Bookingclass(String Bid, String type, String brand, String pick, String drop, String date, String name) {
        this.Bid = Bid;
        this.type = type;
        this.brand = brand;
        this.pick = pick;
        this.drop = drop;
        this.date = date;
        this.name = name;
    }

}