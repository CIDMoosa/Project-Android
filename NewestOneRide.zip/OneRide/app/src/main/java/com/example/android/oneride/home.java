package com.example.android.oneride;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import android.widget.VideoView;

public class home extends AppCompatActivity {

    ImageView i1,i2;
    Button b1,b2;
    VideoView v1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        i1=(ImageView)findViewById(R.id.i1);
        i2=(ImageView)findViewById(R.id.i2);
        i1.setImageResource(R.drawable.oneridelogo);
        i2.setImageResource(R.drawable.b);
        b1=(Button)findViewById(R.id.b1);
        b2=(Button)findViewById(R.id.b2);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i2.setVisibility(View.INVISIBLE);
                v1 = (VideoView)findViewById(R.id.v1);
                Uri uri = Uri.parse("android.resource://"+getPackageName()+"/"+R.raw.a);
                v1.setVideoURI(uri);
                v1.start();
                v1.setVisibility(View.VISIBLE);
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                v1.setVisibility(View.INVISIBLE);
                i2.setVisibility(View.VISIBLE);
            }
        });


        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        Toast.makeText(this, item.getTitle(), Toast.LENGTH_SHORT).show();


        if (id == R.id.Login) {

            Intent i = new Intent(this,Login.class);
            startActivity(i);
        }

        if (id == R.id.Registration) {

            Intent i = new Intent(this,Registration.class);
            startActivity(i);
        }

        if (id == R.id.Gallery) {

            Intent i = new Intent(this,Gallery.class);
            startActivity(i);
        }

        return super.onOptionsItemSelected(item);
    }
}
